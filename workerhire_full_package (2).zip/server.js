// Simple Express backend to create Razorpay orders.
// Usage:
//   export RAZORPAY_KEY_ID=rzp_live_xxx
//   export RAZORPAY_KEY_SECRET=yyy
//   node server.js
const express = require('express');
const bodyParser = require('body-parser');
const Razorpay = require('razorpay');
const cors = require('cors');

const app = express();
app.use(bodyParser.json());
app.use(cors());

const KEY_ID = process.env.RAZORPAY_KEY_ID || '';
const KEY_SECRET = process.env.RAZORPAY_KEY_SECRET || '';

let razorpay = null;
if(KEY_ID && KEY_SECRET){
  razorpay = new Razorpay({ key_id: KEY_ID, key_secret: KEY_SECRET });
  console.log('Razorpay initialized');
} else {
  console.log('Razorpay keys not set. /create-order will fail without keys.');
}

app.post('/create-order', async (req, res) => {
  try {
    if(!razorpay) return res.status(500).json({error:'Razorpay not configured'});
    const { amount, currency='INR', notes } = req.body;
    if(!amount) return res.status(400).json({error:'amount required'});
    // platform commission 10% (example)
    const commission = Math.round(amount * 0.10);
    const amount_after_commission = amount - commission;

    const options = {
      amount, // in paise
      currency,
      receipt: 'rcpt_' + Date.now(),
      notes: Object.assign({}, notes, {commission, amount_after_commission})
    };
    const order = await razorpay.orders.create(options);
    // return order and also key_id so frontend can use it if needed
    res.json(Object.assign({}, order, { key_id: KEY_ID }));
  } catch (e) {
    console.error('create-order error', e);
    res.status(500).json({error: String(e)});
  }
});

const port = process.env.PORT || 3000;
app.listen(port, ()=> console.log('Server listening on', port));
